const { add, array } = require('./module')

console.log(add(2, 3));

console.log(array([1, 2, 3, 4, 5]));